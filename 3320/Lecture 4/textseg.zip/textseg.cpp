/*  to compile: 
    g++ -std=c++17 -O2 textseg.cpp -o textseg.exe
    to run: 
    ./textseg.exe cinderalla_trim.txt
 */
#include <string>
#include <string_view>
#include <vector>
#include <unordered_set>
#include <iostream>
#include <fstream>
#include <chrono>
#include <stdio.h>
#include <algorithm>

using namespace std;

unordered_set<string> wordset;
vector<string> result; 
// is s a word? 
bool IsWord(const char* s, int len)
{
    if (len==0) return true; 
    string str(s, len);
    // string_view str(s,len);
    bool found = (wordset.find(str) != wordset.end());
    if (len>1){
        str[0] = toupper(str[0]);
        found = (wordset.find(str) != wordset.end());
        if (found) return found; 
        str[0] = tolower(str[0]);
        found = (wordset.find(str) != wordset.end());
        return found; 
    }
    return found;
}

// is A[j..n) splitable? 
bool RecSplittable(const char *A, int j, int n)
{
    if (j>=n) return true; 
    for (int i=j+1; i<=n; i++) {
        if (IsWord(&A[j], i-j) && RecSplittable(A, i, n))
            return true; 
    }
    return false; 
}

bool FastSplitTable(const char *A, int j, int n)
{
    vector<bool> SplitTable(n+1); 
    vector<int> sp_trace(n+1, -1); 

    SplitTable[n] = true; 
    for (int i=n-1; i>=0; i--) {
        SplitTable[i] = false;

        for (int j=min(n,i+30); j>=i+1; j--) {
            bool iw = IsWord(&A[i], j-i); 
            // string s(&A[i],j-i);

            if (iw && SplitTable[j]) {
                SplitTable[i] = true; 
                sp_trace[i] = j;
                // printf("i=%d, j=%d, s=%s\n", i, j, s.c_str() );
                break; 
            }
        }

    }
    int i = 0; 
    while (sp_trace[i]!= -1) {
        int j = sp_trace[i]; 
        string s(&A[i], j-i); 
        result.push_back(s); 
        i = j; 
    }


    return SplitTable[0];
}

int main(int argc, char** argv)
{
    ifstream wordfile {"words.noapo"};
    if (!wordfile) {
        cerr << "can't open file words" << endl;
        exit(1);
    }
    string word; 
    
    while ( wordfile ) {
        wordfile >> word; 
        wordset.insert(word);
    }
    cout << "wordset has " << wordset.size() << " words\n"; 
    if (argc<2) {
        cout << "usage: exec textfile" << endl;
        exit(1);
    }
    ifstream textfile { argv[1] };
    string text;
    textfile >> text;
    // transform(text.begin(), text.end(), text.begin(),
    //         [](unsigned char c) { return tolower(c);});
    // cout << "text\n" << text; 
    cout << endl;

    
    {

        auto t1 = chrono::high_resolution_clock::now(); 
        auto res = RecSplittable(text.c_str(), 0, text.size());
        auto t2 = chrono::high_resolution_clock::now(); 
        cout << "text file is segmentable? " << res  << endl;
        cout << "string size " << text.size() << " takes " 
            << std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count() 
            << " milliseconds\n"; 
        cout << endl;
    }

    {
        auto t1 = chrono::high_resolution_clock::now(); 
        auto res =FastSplitTable(text.c_str(), 0, text.size());
        auto t2 = chrono::high_resolution_clock::now(); 
        cout << "text file is segmentable? " << res  << endl;
        cout << "string size " << text.size() << " takes " 
            << std::chrono::duration_cast<std::chrono::milliseconds>(t2-t1).count()  
            << " milliseconds\n"; 
        cout << "segmented words\n"; 
        for (auto word : result) {
            cout << word << ' '; 
        }
    }
    cout << endl;

    return 0;
}


